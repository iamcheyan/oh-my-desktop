package service

import (
	"sync"
	"testing"
	"time"
)

// TestConcurrentOperationsNoRace hammers Toggle/Cancel/State concurrently.
// Regression guard for the K6 races (2026-08 review): runTranscription used
// to read the opMu-guarded opTranslate/testSpeechOnly flags without the lock
// while concurrent toggles rewrote them, and Cancel/finishRecording read the
// stateMu-guarded recordingPath/recordingGeneration fields under opMu only.
// Run with -race; the pre-fix tree reports DATA RACE on this test.
func TestConcurrentOperationsNoRace(t *testing.T) {
	d, _, tr, _ := testDaemon(t, testPaths(t))
	// Slow transcription widens the window in which the pipeline goroutine
	// reads the operation flags while other ops rewrite them.
	tr.mu.Lock()
	tr.text = "hello world"
	tr.mu.Unlock()

	const rounds = 30
	var wg sync.WaitGroup

	// State() sampler (exercises the stateMu-guarded snapshot fields).
	stop := make(chan struct{})
	wg.Add(1)
	go func() {
		defer wg.Done()
		for {
			select {
			case <-stop:
				return
			default:
				_ = d.State()
				time.Sleep(time.Millisecond)
			}
		}
	}()

	for i := 0; i < rounds; i++ {
		// Start a translate-operation recording, then finish it so the
		// pipeline goroutine runs with opTranslate=true.
		if _, perr := d.TestToggleTranslation(); perr != nil {
			t.Fatalf("start toggle: %v", perr)
		}
		if _, perr := d.TestToggleTranslation(); perr != nil {
			t.Fatalf("finish toggle: %v", perr)
		}
		// Concurrently cancel and start a plain toggle; these rewrite the
		// operation flags under opMu while the pipeline reads them.
		_, _ = d.Cancel()
		if _, perr := d.Toggle(); perr != nil {
			t.Fatalf("plain toggle: %v", perr)
		}
		if _, perr := d.Toggle(); perr != nil {
			t.Fatalf("plain finish: %v", perr)
		}
		// Drain back to a terminal phase before the next round.
		deadline := time.Now().Add(5 * time.Second)
		for {
			s := d.State()
			if s.Phase != "transcribing" && s.Phase != "pasting" && s.Phase != "recording" {
				break
			}
			if time.Now().After(deadline) {
				t.Fatalf("pipeline did not settle; phase=%s", s.Phase)
			}
			time.Sleep(5 * time.Millisecond)
		}
		_, _ = d.Cancel()
	}

	close(stop)
	wg.Wait()
	d.Shutdown()
}

// TestShutdownCancelsInFlightTranscription verifies Shutdown returns
// promptly while an engine call is blocked, instead of waiting out the
// 2-minute transcribe timeout (the pre-fix Shutdown stalled behind opMu
// while the pipeline held engine calls).
func TestShutdownCancelsInFlightTranscription(t *testing.T) {
	d, _, tr, _ := testDaemon(t, testPaths(t))
	tr.mu.Lock()
	tr.block = make(chan struct{}) // Transcribe blocks until ctx cancel
	tr.mu.Unlock()

	if _, perr := d.Toggle(); perr != nil {
		t.Fatalf("start: %v", perr)
	}
	if _, perr := d.Toggle(); perr != nil {
		t.Fatalf("finish: %v", perr)
	}

	done := make(chan struct{})
	go func() {
		d.Shutdown()
		close(done)
	}()
	select {
	case <-done:
		// Shutdown returned without waiting for the blocked Transcribe.
	case <-time.After(5 * time.Second):
		t.Fatal("Shutdown stalled behind an in-flight transcription")
	}
	if !tr.wasShutdown() {
		t.Fatal("worker was not shut down")
	}
}
